﻿using System.Security.Cryptography;
using System.Text;

public static class PasswordHelper
{
    public static (string Hash, string Salt) CreatePasswordHash(string password)
    {
        // Generate a salt
        using (var rng = new RNGCryptoServiceProvider())
        {
            var saltBytes = new byte[16];
            rng.GetBytes(saltBytes);
            var salt = Convert.ToBase64String(saltBytes);

            using (var hmac = new HMACSHA256(Convert.FromBase64String(salt)))
            {
                var passwordBytes = Encoding.UTF8.GetBytes(password);
                var hash = hmac.ComputeHash(passwordBytes);
                return (Convert.ToBase64String(hash), salt);
            }
        }
    }

    public static bool VerifyPassword(string password, string storedHash, string storedSalt)
    {
        var saltBytes = Convert.FromBase64String(storedSalt);
        using (var hmac = new HMACSHA256(saltBytes))
        {
            var passwordBytes = Encoding.UTF8.GetBytes(password);
            var hash = hmac.ComputeHash(passwordBytes);
            return Convert.ToBase64String(hash) == storedHash;
        }
    }
}
