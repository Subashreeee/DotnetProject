using ApplicationBootstrap.Models;
using ApplicationBootstrap.Repositories;
using Microsoft.AspNetCore.Mvc;


namespace ApplicationBootstrap.Controllers
{
    public class HomeController : Controller
    {
        private readonly UserRepository _userRepository;

        public HomeController(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        // GET: Register
        public IActionResult Register()
        {
            return View(new User());
        }
        public IActionResult Index()
        {
            return View(); // You can return a view with or without a model
        }
        public IActionResult Courses()
        {
            return View(); // You can return a view with or without a model
        }
        public IActionResult Login()
        {
            return View(); // You can return a view with or without a model
        }


        [HttpPost]
        public async Task<IActionResult> Register(User user)
        {
            if (ModelState.IsValid)
            {
                var existingUser = await _userRepository.GetUserByUsernameAsync(user.Username);
                if (existingUser != null)
                {
                    ModelState.AddModelError("Username", "Username already exists.");
                    return View(user);
                }

                await _userRepository.AddUserAsync(user);
                return RedirectToAction("UserList");
            }

            return View(user);
        }




        // GET: User List
        public async Task<IActionResult> UserList()
        {
            var users = await _userRepository.GetAllUsersAsync();
            return View(users);
        }

        // GET: Edit User
        public async Task<IActionResult> Edit(int id)
        {
            var user = await _userRepository.GetUserByIdAsync(id);
            if (user == null)
            {
                return NotFound();
            }
            return View(user);
        }

        // POST: Edit User
        [HttpPost]
        public async Task<IActionResult> Edit(int id, User user)
        {
            if (ModelState.IsValid)
            {
                var existingUser = await _userRepository.GetUserByIdAsync(id);
                if (existingUser != null)
                {
                    existingUser.Username = user.Username;
                    // If a new password is provided, update it
                    if (!string.IsNullOrWhiteSpace(user.Password))
                    {
                        existingUser.Password = user.Password; // Assuming Password is a property for temporary use
                    }

                    await _userRepository.UpdateUserAsync(existingUser);
                    return RedirectToAction("UserList");
                }

                ModelState.AddModelError(string.Empty, "User not found.");
            }

            return View(user);
        }

        // POST: Delete User
        [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            await _userRepository.DeleteUserAsync(id);
            return RedirectToAction("UserList");
        }
    }
}