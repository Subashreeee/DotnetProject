﻿using ApplicationBootstrap.Models;
using Microsoft.EntityFrameworkCore;

namespace ApplicationBootstrap.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasKey(u => u.Id);

            modelBuilder.Entity<User>()
                .Property(u => u.Username)
                .IsRequired()
                .HasMaxLength(100);

            modelBuilder.Entity<User>()
                .Property(u => u.EncryptedPassword)
                .HasMaxLength(255); // Optional: set max length for this field

            modelBuilder.Entity<User>()
                .Property(u => u.Salt)
                .HasMaxLength(255); // Optional: set max length for this field

            // Optional: Create a unique index on the Username
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Username)
                .IsUnique();
        }
    }
}
