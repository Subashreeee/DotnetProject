﻿using System.ComponentModel.DataAnnotations;

namespace ApplicationBootstrap.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; } // Plain password for simplicity

        public string? EncryptedPassword { get; set; } // Nullable to avoid required error
        public string? Salt { get; set; } // Nullable to avoid required error
    }
}
